"""Scheduling engine for the Smart Disk Scheduler.

Implements FCFS, SSTF, SCAN, C-SCAN, LOOK and C-LOOK. Each function returns the
path of the head: the starting cylinder followed by every cylinder visited, in
order. Total head movement is the sum of the distances between consecutive
cylinders on that path (the return jump of C-SCAN and C-LOOK is counted).

Run from the command line:
    python scheduler.py --smart
    python scheduler.py --queue 98 183 37 122 14 124 65 67 --head 53 --size 200
"""
import argparse

ALGORITHMS = ["FCFS", "SSTF", "SCAN", "C-SCAN", "LOOK", "C-LOOK"]


def validate_input(requests, head, size):
    """Return a clean list of requests or raise ValueError with a clear message."""
    if not isinstance(size, int) or size < 2:
        raise ValueError("Disk size must be a whole number of at least 2.")
    if not isinstance(head, int) or not 0 <= head < size:
        raise ValueError(f"Head position must be between 0 and {size - 1}.")
    if not requests:
        raise ValueError("Enter at least one request cylinder.")
    clean = []
    for r in requests:
        if isinstance(r, bool) or not isinstance(r, int):
            raise ValueError(f"'{r}' is not a valid cylinder number.")
        if not 0 <= r < size:
            raise ValueError(f"Request {r} is outside the disk (0 to {size - 1}).")
        clean.append(r)
    return clean


def total_movement(path):
    """Total head movement along a path."""
    return sum(abs(a - b) for a, b in zip(path, path[1:]))


def fcfs(requests, head, size, direction="up"):
    return [head] + list(requests)


def sstf(requests, head, size, direction="up"):
    pending, current, path = list(requests), head, [head]
    while pending:
        nearest = min(pending, key=lambda r: abs(r - current))
        pending.remove(nearest)
        path.append(nearest)
        current = nearest
    return path


def _split(requests, head):
    higher = sorted(r for r in requests if r >= head)
    lower = sorted((r for r in requests if r < head), reverse=True)
    return higher, lower


def scan(requests, head, size, direction="up"):
    higher, lower = _split(requests, head)
    if direction == "up":
        return [head] + higher + ([size - 1] if lower else []) + lower
    return [head] + lower + ([0] if higher else []) + higher


def cscan(requests, head, size, direction="up"):
    higher, lower = _split(requests, head)
    if direction == "up":
        return [head] + higher + ([size - 1, 0] if lower else []) + sorted(lower)
    return [head] + lower + ([0, size - 1] if higher else []) + sorted(higher, reverse=True)


def look(requests, head, size, direction="up"):
    higher, lower = _split(requests, head)
    return [head] + (higher + lower if direction == "up" else lower + sorted(higher))


def clook(requests, head, size, direction="up"):
    higher, lower = _split(requests, head)
    if direction == "up":
        return [head] + higher + sorted(lower)
    return [head] + lower + sorted(higher, reverse=True)


FUNCTIONS = {"FCFS": fcfs, "SSTF": sstf, "SCAN": scan, "C-SCAN": cscan, "LOOK": look, "C-LOOK": clook}


def run_algorithm(name, requests, head, size, direction="up"):
    """Run one algorithm and return (path, total head movement)."""
    path = FUNCTIONS[name](requests, head, size, direction)
    return path, total_movement(path)


def _parse_args():
    p = argparse.ArgumentParser(description="Smart Disk Scheduler")
    p.add_argument("--queue", type=int, nargs="+", default=[98, 183, 37, 122, 14, 124, 65, 67])
    p.add_argument("--head", type=int, default=53)
    p.add_argument("--size", type=int, default=200)
    p.add_argument("--direction", choices=["up", "down"], default="up")
    p.add_argument("--smart", action="store_true", help="show the recommended algorithm")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    from selector import select_best  # imported here to avoid a circular import

    try:
        reqs = validate_input(args.queue, args.head, args.size)
    except ValueError as err:
        raise SystemExit(f"Error: {err}")
    result = select_best(reqs, args.head, args.size, args.direction)
    print(f"Requests: {reqs}  Head: {args.head}  Disk size: {args.size}  Direction: {args.direction}\n")
    print(f"{'Algorithm':<9} {'Total movement':>14}")
    for r in result["results"]:
        print(f"{r['name']:<9} {r['total']:>14}")
    if args.smart:
        b, f = result["best"], result["fair"]
        print(f"\nRecommended: {b['name']} ({b['total']})")
        print(f"Best starvation-free: {f['name']} ({f['total']})")
