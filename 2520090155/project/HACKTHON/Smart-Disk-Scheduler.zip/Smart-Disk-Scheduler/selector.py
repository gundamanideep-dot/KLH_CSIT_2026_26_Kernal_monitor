"""Smart selector: compares all algorithms and recommends the best one."""
from scheduler import ALGORITHMS, run_algorithm

# SSTF can starve far-away requests, so it is excluded from the "fair" choice.
STARVATION_FREE = {"FCFS": True, "SSTF": False, "SCAN": True, "C-SCAN": True, "LOOK": True, "C-LOOK": True}


def select_best(requests, head, size, direction="up"):
    """Run every algorithm on the same input.

    Returns a dict with:
      results - list of {name, path, total} in the standard order
      best    - the entry with the least total head movement
      fair    - the entry with the least movement among starvation-free algorithms
    Ties are resolved in favour of the algorithm listed first in ALGORITHMS.
    """
    results = []
    for name in ALGORITHMS:
        path, total = run_algorithm(name, requests, head, size, direction)
        results.append({"name": name, "path": path, "total": total})
    best = min(results, key=lambda r: r["total"])
    fair = min((r for r in results if STARVATION_FREE[r["name"]]), key=lambda r: r["total"])
    return {"results": results, "best": best, "fair": fair}
