# Smart Disk Scheduler

An Operating Systems project that compares six disk-scheduling algorithms on the same request queue and automatically recommends the one with the least head movement. It also reports the best starvation-free alternative, so speed is not gained at the cost of fairness.

**Department of CSIT, K L (Deemed to be) University**

## Team

| Name | Roll number |
|---|---|
| R. Sai Charan Reddi | 2520090184 |
| G. ManiDeep Patel | 2520090100 |
| P. Akhil Yadav | 2520090155 |

## Features

- FCFS, SSTF, SCAN, C-SCAN, LOOK and C-LOOK scheduling
- Service order and total head movement for each algorithm
- Smart selector: recommended algorithm plus best starvation-free choice
- Tkinter dashboard with a head-movement graph and comparison table
- Input validation with clear error messages
- Command-line mode and a browser demo (`website/index.html`)

## Project structure

```
scheduler.py            Scheduling engine (six algorithms) and command-line mode
selector.py             Smart selector
dashboard.py            Tkinter GUI with Matplotlib graph
tests/test_scheduler.py Unit tests
website/index.html      Browser demo (open the file in any browser)
requirements.txt        Python dependencies
```

## Setup

Python 3.8 or newer.

```bash
pip install -r requirements.txt
# Ubuntu / WSL only, if Tkinter is missing:
sudo apt install python3-tk
```

## Run

GUI dashboard:

```bash
python dashboard.py
```

Command line:

```bash
python scheduler.py --smart
python scheduler.py --queue 98 183 37 122 14 124 65 67 --head 53 --size 200 --direction up --smart
```

Tests:

```bash
python -m unittest discover -s tests -v
```

## Example

Requests `98, 183, 37, 122, 14, 124, 65, 67`, head at cylinder 53, disk of 200 cylinders, moving toward higher cylinders first:

| Algorithm | Total head movement |
|---|---|
| FCFS | 640 |
| SSTF | 236 |
| SCAN | 331 |
| C-SCAN | 382 (includes the return jump) |
| LOOK | 299 |
| C-LOOK | 322 |

The selector recommends **SSTF (236)** and names **LOOK (299)** as the best starvation-free choice.

## How the selector works

1. Run all six algorithms on the same input.
2. Recommend the algorithm with the least total head movement.
3. Among the starvation-free algorithms (everything except SSTF), also report the one with the least movement.

## Limitations

- Works on a static request queue entered by the user.
- Simulates disk movement; it does not control a real disk.
- Rotational latency and transfer time are not included.

## Future enhancements

- Accept requests while the scheduler is running
- Include rotational latency in the cost model
- Add N-Step SCAN and FSCAN
- Predict the best algorithm from the workload pattern
- Export results and graphs to files

## Screenshots

Add your screenshots to a `screenshots/` folder and link them here.
