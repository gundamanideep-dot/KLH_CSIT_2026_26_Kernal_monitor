import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scheduler import run_algorithm, validate_input, total_movement  # noqa: E402
from selector import select_best  # noqa: E402

QUEUE, HEAD, SIZE = [98, 183, 37, 122, 14, 124, 65, 67], 53, 200


class StandardExample(unittest.TestCase):
    """Hand-calculated totals for the classic textbook queue."""

    def check(self, name, expected):
        self.assertEqual(run_algorithm(name, QUEUE, HEAD, SIZE)[1], expected)

    def test_fcfs(self): self.check("FCFS", 640)
    def test_sstf(self): self.check("SSTF", 236)
    def test_scan(self): self.check("SCAN", 331)
    def test_cscan(self): self.check("C-SCAN", 382)
    def test_look(self): self.check("LOOK", 299)
    def test_clook(self): self.check("C-LOOK", 322)

    def test_sstf_path(self):
        self.assertEqual(run_algorithm("SSTF", QUEUE, HEAD, SIZE)[0], [53, 65, 67, 37, 14, 98, 122, 124, 183])


class SmartSelector(unittest.TestCase):
    def test_recommendation(self):
        r = select_best(QUEUE, HEAD, SIZE)
        self.assertEqual(r["best"]["name"], "SSTF")
        self.assertEqual(r["best"]["total"], 236)
        self.assertEqual(r["fair"]["name"], "LOOK")
        self.assertEqual(r["fair"]["total"], 299)

    def test_every_algorithm_serves_every_request(self):
        for direction in ("up", "down"):
            for item in select_best(QUEUE, HEAD, SIZE, direction)["results"]:
                for req in QUEUE:
                    self.assertIn(req, item["path"], f"{item['name']} {direction}")

    def test_total_matches_path(self):
        for item in select_best(QUEUE, HEAD, SIZE, "down")["results"]:
            self.assertEqual(item["total"], total_movement(item["path"]))


class Validation(unittest.TestCase):
    def test_valid(self): self.assertEqual(validate_input([1, 2], 0, 10), [1, 2])
    def test_empty(self): self.assertRaises(ValueError, validate_input, [], 0, 10)
    def test_out_of_range(self): self.assertRaises(ValueError, validate_input, [10], 0, 10)
    def test_negative(self): self.assertRaises(ValueError, validate_input, [-1], 0, 10)
    def test_bad_head(self): self.assertRaises(ValueError, validate_input, [1], 10, 10)
    def test_bad_size(self): self.assertRaises(ValueError, validate_input, [1], 0, 1)


if __name__ == "__main__":
    unittest.main()
