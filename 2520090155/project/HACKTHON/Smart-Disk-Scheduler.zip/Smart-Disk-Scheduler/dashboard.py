"""Tkinter dashboard for the Smart Disk Scheduler.

Run with:  python dashboard.py
Requires matplotlib (see requirements.txt). Tkinter ships with Python; on Ubuntu
install it with:  sudo apt install python3-tk
"""
import random
import re
import tkinter as tk
from tkinter import ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from scheduler import validate_input
from selector import select_best, STARVATION_FREE


class Dashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart Disk Scheduler")
        self.geometry("1020x640")
        self.minsize(900, 560)
        self.result = None
        self._build_inputs()
        self._build_results()
        self.run()

    # ---------- layout ----------
    def _build_inputs(self):
        box = ttk.LabelFrame(self, text="Input", padding=12)
        box.pack(side="left", fill="y", padx=12, pady=12)
        self.queue_var = tk.StringVar(value="98, 183, 37, 122, 14, 124, 65, 67")
        self.head_var = tk.StringVar(value="53")
        self.size_var = tk.StringVar(value="200")
        self.dir_var = tk.StringVar(value="up")
        ttk.Label(box, text="Request queue (comma or space separated)").pack(anchor="w")
        ttk.Entry(box, textvariable=self.queue_var, width=34).pack(anchor="w", pady=(2, 10))
        ttk.Label(box, text="Head position").pack(anchor="w")
        ttk.Entry(box, textvariable=self.head_var, width=12).pack(anchor="w", pady=(2, 10))
        ttk.Label(box, text="Disk size (cylinders)").pack(anchor="w")
        ttk.Entry(box, textvariable=self.size_var, width=12).pack(anchor="w", pady=(2, 10))
        ttk.Label(box, text="Initial direction").pack(anchor="w")
        ttk.Radiobutton(box, text="Toward higher cylinders", variable=self.dir_var, value="up").pack(anchor="w")
        ttk.Radiobutton(box, text="Toward lower cylinders", variable=self.dir_var, value="down").pack(anchor="w")
        row = ttk.Frame(box)
        row.pack(anchor="w", pady=14)
        ttk.Button(row, text="Run scheduler", command=self.run).pack(side="left")
        ttk.Button(row, text="Random queue", command=self.randomize).pack(side="left", padx=8)
        self.error_var = tk.StringVar()
        ttk.Label(box, textvariable=self.error_var, foreground="#c0243f", wraplength=260).pack(anchor="w")

    def _build_results(self):
        right = ttk.Frame(self)
        right.pack(side="left", fill="both", expand=True, padx=(0, 12), pady=12)
        self.pick_var = tk.StringVar()
        ttk.Label(right, textvariable=self.pick_var, font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
        self.fig = Figure(figsize=(6, 3.4), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=right)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, pady=8)
        cols = ("algorithm", "movement", "fair")
        self.table = ttk.Treeview(right, columns=cols, show="headings", height=6)
        for c, t, w in zip(cols, ("Algorithm", "Total head movement", "Starvation-free"), (110, 160, 140)):
            self.table.heading(c, text=t)
            self.table.column(c, width=w, anchor="w")
        self.table.pack(fill="x")
        self.table.bind("<<TreeviewSelect>>", self.on_select)
        self.order_var = tk.StringVar()
        ttk.Label(right, textvariable=self.order_var, wraplength=640, justify="left").pack(anchor="w", pady=6)

    # ---------- actions ----------
    def randomize(self):
        try:
            size = int(self.size_var.get())
        except ValueError:
            size = 200
        self.queue_var.set(", ".join(str(random.randrange(size)) for _ in range(8)))
        self.head_var.set(str(random.randrange(size)))
        self.run()

    def run(self):
        self.error_var.set("")
        try:
            tokens = [t for t in re.split(r"[\s,]+", self.queue_var.get().strip()) if t]
            requests = []
            for t in tokens:
                if not t.isdigit():
                    raise ValueError(f"'{t}' is not a valid cylinder number. Use whole numbers only.")
                requests.append(int(t))
            head, size = int(self.head_var.get()), int(self.size_var.get())
            requests = validate_input(requests, head, size)
        except ValueError as err:
            self.error_var.set(str(err))
            return
        self.size = size
        self.result = select_best(requests, head, size, self.dir_var.get())
        best, fair = self.result["best"], self.result["fair"]
        self.pick_var.set(f"Recommended: {best['name']} ({best['total']})    Best starvation-free: {fair['name']} ({fair['total']})")
        self.table.delete(*self.table.get_children())
        for r in self.result["results"]:
            self.table.insert("", "end", iid=r["name"],
                              values=(r["name"], r["total"], "Yes" if STARVATION_FREE[r["name"]] else "No"))
        self.table.selection_set(best["name"])

    def on_select(self, _event=None):
        sel = self.table.selection()
        if not sel or not self.result:
            return
        entry = next(r for r in self.result["results"] if r["name"] == sel[0])
        self.draw(entry)

    def draw(self, entry):
        path = entry["path"]
        self.ax.clear()
        self.ax.plot(path, range(len(path)), marker="o", color="#6d4ae8")
        self.ax.plot(path[0], 0, marker="o", markersize=10, color="#f5a524")
        self.ax.set_xlim(0, self.size - 1)
        self.ax.invert_yaxis()
        self.ax.set_xlabel("Cylinder")
        self.ax.set_ylabel("Step")
        self.ax.set_title(f"{entry['name']}: total head movement {entry['total']}")
        self.ax.grid(alpha=0.3)
        self.fig.tight_layout()
        self.canvas.draw()
        self.order_var.set(f"{entry['name']} service order: " + " -> ".join(map(str, path)))


if __name__ == "__main__":
    Dashboard().mainloop()
