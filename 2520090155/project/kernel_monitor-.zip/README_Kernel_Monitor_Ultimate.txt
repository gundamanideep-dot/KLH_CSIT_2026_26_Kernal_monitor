KERNEL MONITOR ULTIMATE — FRONTEND PROTOTYPE

Open kernel_monitor_dashboard_ultimate.html in a browser.

Added in this version:
- Light/dark theme toggle
- Diagnostics section and run checks button
- Process search and sorting (kept from prior version)
- Auto-refresh demo toggle, resource threshold checks, event log, JSON snapshot export
- Existing dashboard layout and features preserved

Important:
This remains a frontend demo using sample metrics. Live Linux metrics require a backend/collector
running on Ubuntu that reads /proc/stat, /proc/meminfo, /proc/uptime and /proc/[pid], then exposes
those metrics to the dashboard. The diagnostics intentionally reports that the live collector is pending.
