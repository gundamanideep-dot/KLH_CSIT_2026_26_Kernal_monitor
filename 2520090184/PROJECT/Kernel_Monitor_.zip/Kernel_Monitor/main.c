#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define PROC_ROOT "/proc"
#define MAX_LINE 512
#define PROCESS_LIMIT 25

typedef struct {
    unsigned long long total;
    unsigned long long idle;
} CpuTimes;

static volatile sig_atomic_t keep_running = 1;

static void handle_sigint(int signal_number) {
    (void)signal_number;
    keep_running = 0;
}

static int read_first_line(const char *path, char *buffer, size_t size) {
    FILE *file = fopen(path, "r");
    if (file == NULL) {
        return -1;
    }

    if (fgets(buffer, (int)size, file) == NULL) {
        fclose(file);
        return -1;
    }

    fclose(file);
    return 0;
}

static int read_cpu_times(CpuTimes *times) {
    char line[MAX_LINE];
    if (read_first_line("/proc/stat", line, sizeof(line)) != 0) {
        return -1;
    }

    unsigned long long user = 0, nice = 0, system = 0, idle = 0;
    unsigned long long iowait = 0, irq = 0, softirq = 0, steal = 0;

    int fields = sscanf(line, "cpu %llu %llu %llu %llu %llu %llu %llu %llu",
                        &user, &nice, &system, &idle, &iowait,
                        &irq, &softirq, &steal);
    if (fields < 4) {
        return -1;
    }

    times->idle = idle + iowait;
    times->total = user + nice + system + idle + iowait +
                   irq + softirq + steal;
    return 0;
}

static double get_cpu_usage(void) {
    CpuTimes first, second;

    if (read_cpu_times(&first) != 0) {
        return -1.0;
    }

    struct timespec delay = {0, 250000000L};
    nanosleep(&delay, NULL);

    if (read_cpu_times(&second) != 0 || second.total <= first.total) {
        return -1.0;
    }

    unsigned long long total_delta = second.total - first.total;
    unsigned long long idle_delta = second.idle - first.idle;

    if (total_delta == 0) {
        return 0.0;
    }

    return 100.0 * (double)(total_delta - idle_delta) /
           (double)total_delta;
}

static void show_memory(void) {
    FILE *file = fopen("/proc/meminfo", "r");
    if (file == NULL) {
        perror("Cannot read /proc/meminfo");
        return;
    }

    unsigned long long total_kb = 0, available_kb = 0, free_kb = 0;
    char line[MAX_LINE];

    while (fgets(line, sizeof(line), file) != NULL) {
        if (sscanf(line, "MemTotal: %llu kB", &total_kb) == 1) {
            continue;
        }
        if (sscanf(line, "MemAvailable: %llu kB", &available_kb) == 1) {
            continue;
        }
        if (sscanf(line, "MemFree: %llu kB", &free_kb) == 1) {
            continue;
        }
    }
    fclose(file);

    if (total_kb == 0) {
        printf("Memory: unable to read memory totals.\n");
        return;
    }

    unsigned long long used_kb =
        total_kb - (available_kb > 0 ? available_kb : free_kb);
    double used_percent = 100.0 * (double)used_kb / (double)total_kb;

    printf("Total memory     : %.2f GiB\n", total_kb / 1048576.0);
    printf("Used memory      : %.2f GiB (%.1f%%)\n",
           used_kb / 1048576.0, used_percent);
    printf("Available memory : %.2f GiB\n",
           (available_kb > 0 ? available_kb : free_kb) / 1048576.0);
}

static void show_uptime(void) {
    char line[MAX_LINE];
    if (read_first_line("/proc/uptime", line, sizeof(line)) != 0) {
        perror("Cannot read /proc/uptime");
        return;
    }

    double uptime_seconds = 0.0;
    if (sscanf(line, "%lf", &uptime_seconds) != 1) {
        printf("System uptime: unable to parse value.\n");
        return;
    }

    unsigned long long seconds = (unsigned long long)uptime_seconds;
    unsigned long long days = seconds / 86400;
    unsigned long long hours = (seconds % 86400) / 3600;
    unsigned long long minutes = (seconds % 3600) / 60;
    unsigned long long secs = seconds % 60;

    printf("System uptime    : %llu days, %llu hours, %llu minutes, %llu seconds\n",
           days, hours, minutes, secs);
}

static int is_numeric_name(const char *name) {
    if (name == NULL || *name == '\0') {
        return 0;
    }
    for (const unsigned char *p = (const unsigned char *)name; *p; ++p) {
        if (!isdigit(*p)) {
            return 0;
        }
    }
    return 1;
}

static int read_process_info(const char *pid_text, char *name,
                             size_t name_size, long *ppid) {
    char path[256];
    snprintf(path, sizeof(path), "/proc/%s/status", pid_text);

    FILE *file = fopen(path, "r");
    if (file == NULL) {
        return -1; /* Process may have exited while /proc was being read. */
    }

    char line[MAX_LINE];
    name[0] = '\0';
    *ppid = -1;

    while (fgets(line, sizeof(line), file) != NULL) {
        if (strncmp(line, "Name:", 5) == 0) {
            char *value = line + 5;
            while (*value == ' ' || *value == '\t') {
                value++;
            }
            value[strcspn(value, "\r\n")] = '\0';
            snprintf(name, name_size, "%s", value);
        } else if (strncmp(line, "PPid:", 5) == 0) {
            long value;
            if (sscanf(line + 5, "%ld", &value) == 1) {
                *ppid = value;
            }
        }
    }

    fclose(file);
    return name[0] != '\0' ? 0 : -1;
}

static void show_processes(void) {
    DIR *proc = opendir(PROC_ROOT);
    if (proc == NULL) {
        perror("Cannot open /proc");
        return;
    }

    printf("%-10s %-10s %s\n", "PID", "PPID", "PROCESS");
    printf("-----------------------------------------------\n");

    struct dirent *entry;
    int shown = 0;

    while ((entry = readdir(proc)) != NULL && shown < PROCESS_LIMIT) {
        if (!is_numeric_name(entry->d_name)) {
            continue;
        }

        char name[256];
        long ppid;
        if (read_process_info(entry->d_name, name, sizeof(name), &ppid) != 0) {
            continue;
        }

        printf("%-10s %-10ld %s\n", entry->d_name, ppid, name);
        shown++;
    }

    closedir(proc);
    printf("\nShowing up to %d processes. Use `ps -eo pid,ppid,comm` for a full list.\n",
           PROCESS_LIMIT);
}

static void show_dashboard(void) {
    double cpu = get_cpu_usage();

    printf("\n====================================================\n");
    printf("                 KERNEL MONITOR\n");
    printf("       Linux System Information Dashboard\n");
    printf("====================================================\n");

    if (cpu >= 0.0) {
        printf("CPU utilization  : %.1f%%\n", cpu);
    } else {
        printf("CPU utilization  : unavailable (could not read /proc/stat)\n");
    }

    show_memory();
    show_uptime();

    printf("Monitor PID      : %ld\n", (long)getpid());
    printf("Parent process   : %ld\n", (long)getppid());

    printf("====================================================\n");
}

static void live_monitor(void) {
    signal(SIGINT, handle_sigint);
    keep_running = 1;

    printf("Live monitor started. Press Ctrl+C to return to the menu.\n");
    while (keep_running) {
        printf("\033[2J\033[H");
        show_dashboard();
        printf("\nRefreshing every 2 seconds. Press Ctrl+C to stop.\n");
        struct timespec delay = {2, 0};
        while (nanosleep(&delay, &delay) == -1 && errno == EINTR && keep_running) {
            /* Continue waiting unless Ctrl+C was received. */
        }
    }

    signal(SIGINT, SIG_DFL);
    printf("\nLive monitor stopped.\n");
}

int main(void) {
    int choice;

    for (;;) {
        printf("\n========== KERNEL MONITOR MENU ==========\n");
        printf("1. Show system dashboard\n");
        printf("2. List running processes\n");
        printf("3. Start live monitoring\n");
        printf("4. Show current process IDs\n");
        printf("0. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) {
                /* Clear invalid input. */
            }
            if (feof(stdin)) {
                break;
            }
            printf("Invalid input. Enter a menu number.\n");
            continue;
        }

        switch (choice) {
            case 1:
                show_dashboard();
                break;
            case 2:
                show_processes();
                break;
            case 3:
                live_monitor();
                break;
            case 4:
                printf("Current process PID : %ld\n", (long)getpid());
                printf("Parent process PPID : %ld\n", (long)getppid());
                break;
            case 0:
                printf("Exiting Kernel Monitor. Goodbye!\n");
                return 0;
            default:
                printf("Invalid choice. Select 0 to 4.\n");
        }
    }

    return 0;
}
