# Kernel Monitor — OSSP Working Prototype

A lightweight Linux system-monitoring application written in C, based on the submitted Kernel Monitor abstract.

## Features

- CPU utilization estimated from two readings of `/proc/stat`
- Total, used, and available RAM from `/proc/meminfo`
- System uptime from `/proc/uptime`
- Running process names, PIDs, and parent PIDs from `/proc`
- Current monitor PID and parent PID using `getpid()` and `getppid()`
- Menu-driven interface and live refresh mode
- Handles processes that disappear while `/proc` is being read

## Requirements

- Linux/Ubuntu
- GCC
- `make` (optional; GCC can compile directly)

## Compile

Using Make:

```bash
make
```

Or compile directly:

```bash
gcc -Wall -Wextra -Wpedantic -std=c11 -O2 main.c -o kernel_monitor
```

## Run

```bash
./kernel_monitor
```

Menu options:

1. Show system dashboard
2. List running processes (up to 25 entries)
3. Start live monitoring (press Ctrl+C to return to menu)
4. Show current PID and parent PID
0. Exit

## Quick validation

Run these commands in another terminal and compare the values:

```bash
grep -E 'MemTotal|MemAvailable|MemFree' /proc/meminfo
cat /proc/uptime
ps -eo pid,ppid,comm | head -n 15
top
```

CPU utilization is a sample-based estimate and may differ slightly from other monitoring tools because their sampling intervals and formulas can differ.

## Notes

- This prototype reads Linux `/proc` data and is intended to run on Linux/Ubuntu. It is not intended to run unchanged on macOS or Windows.
- Process information can change while it is being read; short-lived processes may be skipped.
- The process list intentionally shows up to 25 processes to keep the terminal output manageable.
- The implementation uses `/proc` and standard C/POSIX interfaces. It displays its own PID and PPID. `fork()` is not needed for this monitoring workflow, so it is not called just to claim use of it.
- Before presenting, run the application on the evaluator's Linux environment and capture actual screenshots/results. Do not claim untested metrics.
